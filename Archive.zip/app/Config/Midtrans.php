<?php

namespace Config;

use CodeIgniter\Config\BaseConfig;

class Midtrans extends BaseConfig
{
    public $serverKey = '';
    public $isProduction = true;
    public $isSanitized = true;
    public $is3ds = true;
}
