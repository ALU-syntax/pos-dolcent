* ~~supporting CREATE INDEX (see  issue 131 )~~

* refactoring of
  * the parser tests (all tests should work, except the open issues)
  * ~~the RENAME statement~~
  * ~~the DROP statement~~

* re-programming of
  * FROM statement 

* finishing of
  * issue 33 (creator should build PARTITION parts) 

